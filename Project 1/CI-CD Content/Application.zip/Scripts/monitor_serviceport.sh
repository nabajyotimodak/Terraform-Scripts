#! /bin/bash
sudo lsof -i:5005
sudo lsof -i:5055