#! /bin/bash
sudo rm -rf /home/ubuntu/Advisory_Chat_Bot/*