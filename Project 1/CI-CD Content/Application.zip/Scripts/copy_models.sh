#! /bin/bash
# sudo mkdir /home/ubuntu/Advisory_Chat_Bot/passed_models
# sudo cp /home/ubuntu/Advisory_Chat_Bot/models/* /home/ubuntu/Advisory_Chat_Bot/passed_models
sudo cp /home/ubuntu/Advisory_Chat_Bot/models/* /home/ubuntu/MODELS/