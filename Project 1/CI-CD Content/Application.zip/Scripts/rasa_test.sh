#! /bin/bash
cd /home/ubuntu/Advisory_Chat_Bot
sudo rasa test --fail-on-prediction-errors