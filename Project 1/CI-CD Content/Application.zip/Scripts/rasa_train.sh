#! /bin/bash
cd /home/ubuntu/Advisory_Chat_Bot
sudo rasa train